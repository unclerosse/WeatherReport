from tkinter import *
import tkinter
class Window:
    def __init__ (self, width = '750', height = '400', name = 'Weather Report'):
        self.width = width
        self.height = height
        self.name = name 

    def CreateWindow (self): 
        root = Tk ()

        root ['bg'] = "DeepSkyBlue2"
        root.title (self.name)
        root.geometry (str (self.width) + 'x' + str (self.height))
        root.resizable (width = False, height = False)
        root.iconbitmap ('materials/logo.ico')
        
        root.mainloop ()