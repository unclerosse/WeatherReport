from Writer import WriteOnFile
from Window import Window

s = input ()
WriteOnFile (s)
n = Window ()
n.CreateWindow ()